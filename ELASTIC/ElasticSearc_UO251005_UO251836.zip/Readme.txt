INSTRUCCIONES PARA EL MANEJO DE NUESTRA APLICACI�N:

-Arrancar ElasticSearch version 6.0.0
-El primer argumento del main es el �ndice y el segundo el t�rmino que se busca.
-Cargar el proyecto en Eclipse
-Crear un nombre para el �ndice.
-Poner un t�rmino de b�squeda.
-Ejecutar la clase desde el main.

-Para descargar la coleccion de tweets acceder con el siguiente enlace
https://unioviedo-my.sharepoint.com/personal/uo251836_uniovi_es/_layouts/15/guestaccess.aspx?docid=04f57f1d09575400fa4290dd3e66946f7&authkey=AeIK0R1gxVIueTju9i5Xkg0&e=737799b22f3741588bd9b63e0f0f8d6f
