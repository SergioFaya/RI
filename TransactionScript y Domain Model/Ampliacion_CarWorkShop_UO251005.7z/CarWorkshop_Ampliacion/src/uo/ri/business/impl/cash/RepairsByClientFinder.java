package uo.ri.business.impl.cash;

public class RepairsByClientFinder {
	
	
	public void execute() {
		
	}
}
