package uo.ri.business.impl.cash;

import java.util.Map;

public class InvoiceFinder {

	@SuppressWarnings("unused")
	private long idInvoice;
		
	public InvoiceFinder(long idInvoice) {
		this.idInvoice = idInvoice;
	}
	
	public Map<String,Object> execute() {
		// TODO Auto-generated method stub

		
		return null;
	}
}
