package uo.ri.business.impl.cash;

import java.util.Map;

public class SettleInvoice {

	
	public SettleInvoice(Long id, Map<Long,Double> map) {
		
		
	}
	
	
	public void execute() {
	
	}

}
