package uo.ri.business.impl.cash;

public class PaymentMeansForInvoiceFinder {

	public PaymentMeansForInvoiceFinder(Long id) {
		// TODO Auto-generated constructor stub
	}
	
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
