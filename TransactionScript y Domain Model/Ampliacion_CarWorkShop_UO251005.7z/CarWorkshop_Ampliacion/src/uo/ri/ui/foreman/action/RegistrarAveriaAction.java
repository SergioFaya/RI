package uo.ri.ui.foreman.action;

import uo.ri.common.BusinessException;
import alb.util.menu.Action;

public class RegistrarAveriaAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub
		
	}

}
