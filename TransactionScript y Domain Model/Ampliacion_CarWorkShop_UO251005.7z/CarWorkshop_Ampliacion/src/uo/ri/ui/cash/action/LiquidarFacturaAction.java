package uo.ri.ui.cash.action;

public class LiquidarFacturaAction {

	public LiquidarFacturaAction() {
		// TODO Auto-generated constructor stub
	}
	
	public void execute() {
		/*new InvoiceFinder().execute();
		new SettleInvoice().execute();
		new PaymentMeansForInvoiceFinder().execute();*/
		

	}
}
